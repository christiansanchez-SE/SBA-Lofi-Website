

What could you have done differently during the planning stages of your project to make the execution easier?


Were there any requirements that were difficult to implement? What do you think would make them easier to implement in future projects?


What would you add to or change about your website if given more time?


Use this space to make notes for your future self about anything that you think is important to remember about this process, or that may aid you when attempting something similar again.
