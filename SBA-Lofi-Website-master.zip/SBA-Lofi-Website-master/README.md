This is a website that has some responsiveness. 
It has 3 pages including the main page. 
The pages are: Main, Login, and Register page.
It also has clickable links. 
Which inculde the drop down -> Our playlist, nad the lofi generes -> each name are clickable that will take you to a youtube video of that artist.
The page will change when changing the orientation.
Lastly it has some hover affects on some of the boxes and words.


Reflection (optional):
What could you have done differently during the planning stages of your project to make the execution easier?
I wish I would have drawn out and wrote some ideas down before editing everything.


Were there any requirements that were difficult to implement? What do you think would make them easier to implement in future projects?
The media queries were a little to get used of with different screen sizes. Have a set template would have made it easier.

What would you add to or change about your website if given more time?
I would ahve added more pages and animations.


Use this space to make notes for your future self about anything that you think is important to remember about this process, or that may aid you when attempting something similar again.
Take your time and finish each section before moving on.

https://github.com/christiansanchez-SE/SBA-Lofi-Website
